import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React from 'react';
import { theming } from 'common/constants/theming';
import { images } from 'common/resources/images';
import { DCLine } from '../line';
import { Community } from 'data/api/community/interfaces';
import { UserImage } from 'components/user_image';
import { useTranslation } from 'react-i18next';
import { useToggleFollowCommunity } from 'data/hooks/community';
import FastImage from 'react-native-fast-image';
import { getImgePath } from 'data/api';

interface CommunityItemProps {
  community: Community;
  click?: () => void;
}

export function CommunityItem({ community, click }: CommunityItemProps) {
  const { t } = useTranslation();
  const slicedCategories = community.categories.slice(0, 2);
  // Remaining elements
  const remainingCategoriesCount =
    community.categories.length - slicedCategories.length;

  const slicedFollowers = community.followers.slice(0, 3);

  const remainingFollowersCount = community.followers.length - 3;
  // Following
  const followMutation = useToggleFollowCommunity();

  const handleFollow = () => {
    followMutation.mutate(community);
  };

  return (
    <TouchableOpacity onPress={click}>
      <View style={styles.item}>
        <View style={styles.itemBody}>
          <View style={styles.itemBodyText}>
            <Text style={styles.itemTitle}>{community.title}</Text>
            <Text style={styles.itemSubtitle} numberOfLines={3}>
              {community.description}{' '}
              <Text style={{ color: theming.colors.purple }}>
                {t('details')}
              </Text>
            </Text>
          </View>

          <View style={styles.itemImage}>
            <FastImage
              source={
                community.images.length > 0
                  ? { uri: getImgePath(community.images[0]) }
                  : images.itemImg
              }
              style={styles.itemImg}
            />
          </View>
        </View>

        <View style={styles.itemSpot}>
          <View style={styles.itemSpotRight}>
            <View style={styles.itemSpotImages}>
              {slicedFollowers.map((user, i) => (
                <UserImage
                  key={user.id}
                  userImage={getImgePath(user.userImage)}
                  style={i === 0 ? styles.itemSpotImg : styles.itemSpotImg1}
                />
              ))}
            </View>
            <Text style={styles.itemSpotTitle}>
              {t(remainingFollowersCount.toString(), 'followers')}
            </Text>
          </View>
        </View>

        <DCLine />

        <View style={styles.itemBottom}>
          <View style={styles.itemTags}>
            {slicedCategories.map((category, i) => (
              <View style={styles.itemTag} key={i}>
                <Text style={styles.itemTagTitle}>{category}</Text>
              </View>
            ))}
            {remainingCategoriesCount > 0 && (
              <View style={styles.itemAnotherTag}>
                <Text style={styles.itemAnotherTagTitle}>
                  +{remainingCategoriesCount}
                </Text>
              </View>
            )}
          </View>
          {!community.isFollowing ? (
            <TouchableOpacity style={styles.itemBtn} onPress={handleFollow}>
              <Text style={styles.itemBtnTitle}>{t('join_small')}</Text>
            </TouchableOpacity>
          ) : (
            <Text style={styles.itemJoined}>Joined</Text>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  item: {
    width: '100%',
    borderWidth: 1,
    borderColor: theming.colors.gray250,
    borderRadius: theming.spacing.SM,
    padding: 12,
    backgroundColor: theming.colors.white,
    marginTop: 15,
  },
  itemBody: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 20,
  },
  itemBodyText: {
    width: '70%',
    flex: 1,
  },
  itemTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theming.colors.textPrimary,
    fontFamily: theming.fonts.latoRegular,
  },
  itemSubtitle: {
    fontWeight: '400',
    fontSize: 14,
    color: theming.colors.gray700,
    fontFamily: theming.fonts.latoRegular,
    marginTop: 6,
  },
  itemImage: {
    width: 80,
    height: 105,
    borderRadius: 6,
    overflow: 'hidden',
  },
  itemImg: {
    width: '100%',
    height: '100%',
    borderRadius: 6,
    resizeMode: 'cover',
  },
  itemSpot: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: theming.spacing.SM,
    marginTop: 10,
    marginBottom: 15,
  },
  itemSpotRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  itemSpotTitle: {
    fontSize: 14,
    fontWeight: '400',
    color: theming.colors.gray700,
    fontFamily: theming.fonts.latoRegular,
  },
  itemSpotImages: {
    flexDirection: 'row',
    position: 'relative',
  },
  itemSpotImg: {
    width: 24,
    height: 24,
    borderRadius: 50,
    position: 'relative',
    borderWidth: 1,
    borderColor: theming.colors.white,
  },
  itemSpotImg1: {
    width: 24,
    height: 24,
    borderRadius: 50,
    position: 'relative',
    left: -6,
    borderWidth: 1,
    borderColor: theming.colors.white,
  },
  itemBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  itemTags: {
    flex: 1,
    flexWrap: 'wrap',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  itemTag: {
    borderWidth: 1,
    borderColor: theming.colors.gray250,
    borderRadius: 4,
    paddingHorizontal: 10,
    paddingVertical: 3,
  },
  itemTagTitle: {
    color: theming.colors.purple,
    fontWeight: '700',
    fontSize: 12,
    fontFamily: theming.fonts.latoRegular,
  },
  itemAnotherTag: {
    borderRadius: 4,
    paddingHorizontal: 10,
    paddingVertical: 3,
    backgroundColor: theming.colors.gray75,
  },
  itemAnotherTagTitle: {
    color: theming.colors.darkGray,
    fontWeight: '700',
    fontSize: 12,
    fontFamily: theming.fonts.latoRegular,
  },
  itemBtn: {
    backgroundColor: theming.colors.orange,
    paddingHorizontal: 26,
    paddingVertical: theming.spacing.SM,
    borderRadius: 100,
  },
  itemBtnTitle: {
    fontWeight: '600',
    fontSize: 14,
    color: theming.colors.white,
    fontFamily: theming.fonts.latoRegular,
  },
  itemJoined: {
    fontSize: 12,
    fontWeight: '700',
    color: theming.colors.gray700,
    fontFamily: theming.fonts.latoRegular,
  },
});
